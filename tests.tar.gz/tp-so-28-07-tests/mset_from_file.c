#include <libmemcached/memcached.h>
#include<libmemcached/memcached_util.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "utilarg.c"


int main(int argc, char *argv[]){

	int puerto = 11211;
	char localhost[] = "127.0.0.1";
	char *path, *ip, *key, *buffer;
	memcached_st *st;
	struct stat info;
	FILE *fp;
	memcached_return_t error;

	ip = localhost;
	if(argc < 3){
		printf("Uso %s key filename [ip] [port] \n", argv[0]);
		print_defaults(ip, puerto);
		exit(1);
	}

	key = argv[1];
	path = argv[2];

	fill_ip_and_port(&ip, &puerto, argv[3], argv[4], argc - 3);	

	st = memcached_create(NULL);
	memcached_behavior_set(st, MEMCACHED_BEHAVIOR_BINARY_PROTOCOL, 1);
	memcached_server_add(st, ip, puerto);


	fp = fopen(path, "r");
	if(fp==NULL){
		perror("fopen");
		exit(1);
	}

	stat(path, &info);
	buffer = malloc(info.st_size);
	fread(buffer, info.st_size, 1, fp);
	fclose(fp);

	error = memcached_set(st, key, strlen(key), buffer, info.st_size, 0, 0);
	if(error == MEMCACHED_SUCCESS)  printf("STORED\n");
			else printf("%s\n", memcached_strerror(st, error));

	free(buffer);
	memcached_free(st);

	return 0;
}
