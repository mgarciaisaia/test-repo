int fill_ip_and_port(char** ip, int * puerto, char * ip_arg, char * port_arg, int argc){
        // Leyendo valores del entorno
        if (getenv("MEM_IP") != NULL){
                *ip = getenv("MEM_IP");
        }

        if (getenv("MEM_PORT") != NULL){
                *puerto = atoi(getenv("MEM_PORT"));
        }

        // Leyendo valores por parametro (que pisan a los del entorno)
        if(argc > 0){
                *ip = ip_arg;
                if(argc > 1) {
                        *puerto = atoi(port_arg);
                }
        }
}


void print_defaults(char * ip, int puerto){
	printf("Defaults: ip = %s, port = %d (Tambien se pueden setear las variables de entorno MEM_IP y MEM_PORT)\n", ip, puerto);
}
