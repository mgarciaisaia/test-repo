#!/bin/bash

source util_char.sh


if [ "$#" -lt "3" ]
then
	echo "Uso: `basename $0` nombreArchivo offset bytes [zeroed|random|char] (offset=eof para agregar al final, zeroed type es el default)"
	exit 1
fi

TO=$1
SEEK=$2
COUNT=$3
TYPE=$4

if [ -z "$TYPE" ]
then
        TYPE=zeroed
        echo "== Setting \"$TYPE\" type by default =="
fi

case $TYPE in

random)
        FROM=/dev/urandom
        ;;
zeroed)
        FROM=/dev/zero
        ;;
char)
	TEMP_FILE=file-$RANDOM.temp
        write_char a $COUNT $TEMP_FILE
	FROM=$TEMP_FILE
        ;;
*)
        echo Tipo de contenido \"$TYPE\" invalido!
        exit 1
        ;;
esac



if [ ! -e $TO ]
then
	echo "== Warning! El archivo \"$TO\" no existe y sera creado! =="
fi

if [ "$SEEK" == "eof" ]
then
	WHERE="oflag=append"
else
	WHERE="seek=$SEEK"
fi


dd if=$FROM of=$TO bs=1 count=$COUNT conv=notrunc,fsync $WHERE


rm -f $TEMP_FILE

